import bcrypt from 'bcryptjs';
import { getDb } from './index.js';
import { users } from './schema.js';
import { eq } from 'drizzle-orm';
import { ALL_PERMISSIONS } from '../types/index.js';
import { log } from '../utils/logger.js';
const SALT_ROUNDS = 12;
export async function hashPassword(password) {
    return bcrypt.hash(password, SALT_ROUNDS);
}
export async function verifyPassword(password, hash) {
    return bcrypt.compare(password, hash);
}
/** Seed the default admin user on first run.
 *  Default credentials:
 *    username: admin
 *    email: admin@liuma.com
 *    password: s20041021
 */
export async function seedDefaultUser() {
    const d = getDb();
    const existing = d.select({ id: users.id }).from(users).where(eq(users.isDefault, 1)).get();
    if (existing) {
        log.info('Primary admin already exists');
        return;
    }
    const password = 's20041021';
    const hash = await hashPassword(password);
    d.insert(users).values({
        username: 'admin',
        email: 'admin@liuma.com',
        password: hash,
        role: 'admin',
        permissions: JSON.stringify(ALL_PERMISSIONS),
        isDefault: 1,
    }).run();
    log.info('Primary admin created — username: "admin", email: "admin@liuma.com"');
}
//# sourceMappingURL=seed.js.map